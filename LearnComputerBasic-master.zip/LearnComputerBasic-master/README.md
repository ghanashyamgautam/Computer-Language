# Learn Computer Basic
Open source application from which people learn basics of computer. 

### Topic Avaiable
- Introduction and Basics
- Generation of Computer
- Parts of Computer
- Useful Softwares
- MS Word
- Ms Excel
- Ms Powerpoint
- Computer Shortcults
- How to Guide