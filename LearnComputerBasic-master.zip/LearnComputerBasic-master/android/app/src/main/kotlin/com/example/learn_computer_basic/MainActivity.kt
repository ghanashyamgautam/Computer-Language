package com.example.learn_computer_basic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
