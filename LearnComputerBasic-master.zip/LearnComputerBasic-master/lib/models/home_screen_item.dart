
class HomePageItem{
  final String title;
  final String subtitle;
  final String image;
  final Function onTap;
  HomePageItem(this.title, this.subtitle, this.image, this.onTap);

}