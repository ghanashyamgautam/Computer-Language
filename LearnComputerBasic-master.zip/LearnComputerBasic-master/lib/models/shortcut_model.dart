class Shortcut{
  String key;
  String result;
  Shortcut(this.key, this.result);
}
